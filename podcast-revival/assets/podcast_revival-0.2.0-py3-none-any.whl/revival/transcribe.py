"""Optional local ASR; machine text is unreviewed and never establishes identity."""
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path


def _time(value):
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value < 0:
        raise ValueError('Timestamps must be finite nonnegative seconds')
    return int(round(value * 1000))


def normalize_local(segments, info, source_id, offset_ms=0):
    """Translate faster-whisper results into original-source absolute timestamps."""
    if not isinstance(offset_ms, int) or isinstance(offset_ms, bool) or offset_ms < 0:
        raise ValueError('offset_ms must be a nonnegative integer')
    normalized = []
    for i, segment in enumerate(segments):
        start, end = _time(segment.start), _time(segment.end)
        if end < start:
            raise ValueError('ASR segment end precedes start')
        row = {'segment_id': '{}_asr_{:05d}'.format(source_id, i), 'start_ms': offset_ms + start,
               'end_ms': offset_ms + end, 'text_verbatim': segment.text.strip(), 'speaker_id': None,
               'attribution_status': 'unknown', 'transcription_status': 'machine_unreviewed',
               'confidence': None, 'avg_logprob': getattr(segment, 'avg_logprob', None),
               'no_speech_prob': getattr(segment, 'no_speech_prob', None)}
        words = getattr(segment, 'words', None)
        if words:
            row['words'] = [{'text': w.word, 'start_ms': offset_ms + _time(w.start),
                             'end_ms': offset_ms + _time(w.end), 'probability': getattr(w, 'probability', None)} for w in words]
        normalized.append(row)
    return {'schema_version': 1, 'source_id': source_id, 'created_at': datetime.now(timezone.utc).isoformat(),
            'provider': 'local_faster_whisper', 'source_offset_ms': offset_ms,
            'language': info.language, 'language_probability': getattr(info, 'language_probability', None),
            'language_verified': False, 'attribution_verified': False, 'diarization_status': 'not_performed',
            'confidence': None, 'duration_seconds': getattr(info, 'duration', None), 'segments': normalized,
            'limitations': ['Automatic text and language require source review.',
                            'No diarization: speaker identities are unknown.',
                            'Local ASR is candidate inspection, not the contracted Scribe v2 result.']}


def transcribe_local(path, source_id, offset_ms=0, model='small', cpu_threads=4, model_instance=None,
                     download_root=None, on_segment=None):
    """Run CPU ASR with bounded threads; auto-detect language without identity guesses.

    Downloads model weights if absent; uploads no audio and makes no paid API calls.
    Caller can reuse model_instance for multiple contexts and persist on_segment progress.
    """
    if not isinstance(cpu_threads, int) or not 1 <= cpu_threads <= 8:
        raise ValueError('cpu_threads must be between 1 and 8')
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    if model_instance is None:
        from faster_whisper import WhisperModel
        model_instance = WhisperModel(model, device='cpu', compute_type='int8', cpu_threads=cpu_threads,
                                      num_workers=1, download_root=str(download_root) if download_root else None)
    segments, info = model_instance.transcribe(str(path), beam_size=3, language=None,
                                               word_timestamps=True, vad_filter=True)
    collected = []
    for segment in segments:
        collected.append(segment)
        if on_segment:
            on_segment(normalize_local([segment], info, source_id, offset_ms)['segments'][0])
    result = normalize_local(collected, info, source_id, offset_ms)
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    result.update(audio_path=str(path), audio_hash=digest.hexdigest(), model=model,
                  compute_type='int8', cpu_threads=cpu_threads, num_workers=1, beam_size=3)
    return result


def save_transcript(result, output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    data = dict(result)
    data['content_hash'] = hashlib.sha256(json.dumps(result, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    temporary = output_path.with_name(output_path.name + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(output_path)
    return data
