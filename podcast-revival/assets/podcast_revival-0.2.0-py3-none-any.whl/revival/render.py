"""Recoverable fal media controller; no paid call without every local gate.

The ledger owns atomic reservation/submission locks. A submitting/unknown job
without a provider ID is never sent again. All artifacts are real downloads;
synthetic inputs cannot enter this paid route.
"""
from datetime import date, datetime, timezone
import math
import fcntl
from pathlib import Path
import re
import time

from .providers import FalProvider, ProviderError, SubmissionRejected
from .util import now, object_hash, read_json, resolve_path, sha256_file, write_json
from .ingest import probe, _binary, _run
from .content import script_hash, validate_script, _inputs

ROUTE = ['fal-ai/minimax/voice-clone', 'fal-ai/minimax/speech-2.8-hd',
         'fal-ai/kling-video/ai-avatar/v2/pro']
AVATAR_PROMPT = 'A podcast character speaking naturally with restrained gestures, fixed camera, preserve the reference appearance and style.'


class RenderBlocked(RuntimeError):
    pass


def _safe(value):
    # User IDs never become arbitrary paths.
    return re.sub(r'[^A-Za-z0-9_-]', '_', str(value))[:100]


def _hash_path(path, expected=None):
    path = Path(path)
    if not path.is_file():
        raise RenderBlocked('missing_reference: ' + str(path))
    digest = sha256_file(path)
    if expected and expected != digest:
        raise RenderBlocked('asset_hash_changed: ' + str(path))
    return digest


def _cached_artifact(path, checksum):
    return Path(path).is_file() and sha256_file(path) == checksum


def _price_gate(config):
    budget = config.get('budget', {})
    if budget.get('allow_paid_calls') is not True or not budget.get('authorization_ref'):
        raise RenderBlocked('paid_calls_not_authorized')
    pricing = config.get('pricing', {})
    if pricing.get('account_verified') is not True:
        raise RenderBlocked('account_price_unverified: verify current account pricing before submission')
    stamp = pricing.get('verified_at')
    try:
        verified = datetime.fromisoformat(stamp.replace('Z', '+00:00')).date()
    except (TypeError, ValueError, AttributeError):
        raise RenderBlocked('price_unverified: dated pricing snapshot required')
    # An old as_of cannot make today's paid prices current.
    if verified != datetime.now(timezone.utc).date():
        raise RenderBlocked('price_unverified: verify current-day account prices')
    for name in ('clone_usd', 'tts_per_1000_chars_usd', 'video_per_second_usd'):
        amount = pricing.get(name)
        if isinstance(amount, bool) or not isinstance(amount, (float, int)) or not math.isfinite(amount) or amount <= 0:
            raise RenderBlocked('price_unverified: ' + name)
    return pricing


def run_job(provider, ledger, operation, fingerprint, upper_bound, endpoint,
            payload_factory, metadata=None, minimum_remaining=0, poll_seconds=0):
    """Submit at most once. Resuming polls only returned URLs, never guesses them."""
    # A new quote cannot rewrite an already accepted request's reservation.
    # Resume/cached work uses its original bound and canonical request metadata.
    existing = next((j for j in ledger.jobs() if j.get('fingerprint') == fingerprint), None)
    if existing:
        request_metadata = lambda m: {k: v for k, v in (m or {}).items() if k != 'plan_slot'}
        if existing['operation'] != operation or request_metadata(existing.get('metadata')) != request_metadata(metadata):
            raise RenderBlocked('fingerprint_metadata_conflict: original request must be reconciled')
        if existing.get('state') == 'reserved' and abs(existing['upper_bound'] - upper_bound) > 0.000001:
            raise RenderBlocked('unsubmitted_price_bound_changed: revise the original unsubmitted reservation explicitly')
        job = existing
    else:
        floor = minimum_remaining(metadata or {}, upper_bound) if callable(minimum_remaining) else minimum_remaining
        job = ledger.reserve(operation, fingerprint, upper_bound, metadata=metadata or {},
                             minimum_remaining=floor)
    jid = job['job_id']
    if job.get('state') in ('complete', 'completed', 'succeeded', 'reconciled') and job.get('result') is not None:
        return job['result']
    request_id = job.get('request_id')
    if not request_id:
        if job.get('state') == 'rejected':
            raise RenderBlocked('submission_rejected: ' + jid + '; correct the recorded cause before a new explicit attempt')
        if job.get('state') != 'reserved':
            raise RenderBlocked('unknown_submission_without_id: ' + jid + '; read-only reconciliation required')
        # Prepare/upload before claiming the irreversible submitting lock.
        payload = payload_factory()
        if not ledger.start(jid):
            raise RenderBlocked('submission_lock_unavailable: ' + jid)
        try:
            response = provider.submit(endpoint, payload)
            request_id = response['request_id']
            urls = {k: response[k] for k in ('status_url', 'response_url', 'cancel_url') if response.get(k)}
            ledger.submitted(jid, request_id, urls)
        except SubmissionRejected as exc:
            ledger.rejected(jid, exc.safe_message)
            raise RenderBlocked('submission_rejected: ' + jid + '; ' + exc.safe_message) from exc
        except Exception as exc:
            ledger.unknown(jid, type(exc).__name__ + ': ' + str(exc))
            raise RenderBlocked('unknown_submission: ' + jid + '; do not resubmit') from exc
        job = ledger.get(jid)
    urls = job.get('urls') or {}
    if not urls.get('status_url') or not urls.get('response_url'):
        raise RenderBlocked('missing_returned_queue_urls: ' + jid + '; reconcile request_id ' + str(request_id))
    deadline = time.monotonic() + min(max(float(poll_seconds), 0), 30)
    while True:
        try:
            status = provider.status(urls['status_url'])
            state = str(status.get('status', '')).upper()
            if state == 'COMPLETED':
                result = provider.result(urls['response_url'])
                if not isinstance(result, dict) or result.get('error'):
                    ledger.unknown(jid, 'provider_result_error')
                    raise RenderBlocked('provider_result_error: ' + jid)
                ledger.complete(jid, result)
                return result
            if state in ('FAILED', 'CANCELLED', 'ERROR'):
                ledger.unknown(jid, 'provider_terminal_' + state.lower())
                raise RenderBlocked('provider_terminal_' + state.lower() + ': ' + jid + '; preserve reservation')
        except ProviderError as exc:
            raise RenderBlocked('queue_query_unavailable: ' + jid + '; resume using original URLs') from exc
        if time.monotonic() >= deadline:
            raise RenderBlocked('queued: ' + jid + '; resume to query original request')
        time.sleep(min(2, max(deadline - time.monotonic(), 0)))


def _download(provider, result, field, path):
    item = result.get(field)
    url = item.get('url') if isinstance(item, dict) else item
    if not isinstance(url, str):
        raise RenderBlocked('provider_result_missing_' + field)
    sidecar = Path(str(path) + '.asset.json')
    if sidecar.exists():
        cached = read_json(sidecar)
        if not _cached_artifact(cached['path'], cached['checksum']):
            raise RenderBlocked('cached_artifact_changed: ' + str(path))
        return cached
    provider.download(url, path)
    metadata = probe(path)
    asset = dict(path=str(path), checksum=sha256_file(path), media_info=metadata,
                 duration_seconds=metadata['duration_seconds'])
    write_json(sidecar, asset)
    return asset


def _ffmpeg(args):
    executable = _binary('ffmpeg')
    if not executable:
        raise RenderBlocked('missing_ffmpeg')
    return _run([executable, '-y', '-v', 'error'] + args)


def _concat_list(paths, path):
    # ffmpeg concat demuxer escaping; actual paths only, never shell text.
    path.write_text(''.join("file '" + str(Path(p).resolve()).replace("'", "'\\''") + "'\n" for p in paths), encoding='utf-8')


def _freeze_audio(parts, folder, script_digest):
    """One canonical PCM piece per turn is both video driver and companion audio."""
    folder.mkdir(parents=True, exist_ok=True)
    chunks = []
    cursor = 0.0
    for index, part in enumerate(parts):
        path = folder / ('turn_%03d.wav' % index)
        expected = part.get('normalized')
        if expected and not _cached_artifact(expected['path'], expected['checksum']):
            raise RenderBlocked('frozen_audio_changed: explicit new attempt required')
        if not path.exists():
            _ffmpeg(['-i', part['path'], '-vn', '-ar', '24000', '-ac', '1', '-c:a', 'pcm_s16le', path])
        info = probe(path)
        chunks.append(dict(turn_id=part['turn_id'], speaker_id=part['speaker_id'], path=str(path),
                           checksum=sha256_file(path), duration_seconds=info['duration_seconds'], start_seconds=cursor))
        cursor += info['duration_seconds']
    listing = folder / 'audio.concat.txt'
    _concat_list([c['path'] for c in chunks], listing)
    combined = folder / 'frozen.wav'
    if not combined.exists():
        _ffmpeg(['-f', 'concat', '-safe', '0', '-i', listing, '-c:a', 'copy', combined])
    info = probe(combined)
    frozen = dict(path=str(combined), checksum=sha256_file(combined), script_hash=script_digest,
                  chunks=chunks, duration_seconds=info['duration_seconds'], media_info=info, frozen_at=now())
    frozen['audio_hash'] = object_hash({'checksum': frozen['checksum'], 'chunks': chunks, 'script_hash': script_digest})
    return frozen


def _assemble(video_parts, audio, folder):
    for chunk in audio['chunks']:
        if not _cached_artifact(chunk['path'], chunk['checksum']):
            raise RenderBlocked('frozen_audio_changed: regenerate dependent video with new fingerprint')
    if not _cached_artifact(audio['path'], audio['checksum']):
        raise RenderBlocked('frozen_audio_changed: final companion track')
    if len(video_parts) != len(audio['chunks']):
        raise RenderBlocked('video_segment_count_mismatch: missing or extra content')
    # Normalize visual codec, size and FPS; avoid concat's unequal-stream failure.
    normalized = []
    alignment_evidence = []
    for index, (video, chunk) in enumerate(zip(video_parts, audio['chunks'])):
        difference = video['duration_seconds'] - chunk['duration_seconds']
        if difference < -0.001:
            raise RenderBlocked('video_shorter_than_frozen_audio: missing content requires manual review')
        if difference > 0.5:
            from .mediacheck import check_tail_padding
            evidence = check_tail_padding(video['path'], chunk['path'], folder / ('alignment_%03d' % index),
                                          target_seconds=chunk['duration_seconds'])
            evidence.update(turn_id=chunk['turn_id'], source_video_checksum=sha256_file(video['path']),
                            frozen_audio_checksum=chunk['checksum'])
            write_json(folder / ('alignment_%03d.json' % index), evidence)
            alignment_evidence.append(evidence)
            if evidence['status'] != 'verified_tail_padding':
                raise RenderBlocked('video_audio_duration_mismatch: tail padding not verified; ' + ', '.join(evidence['issues']))
        target = folder / ('visual_%03d.mp4' % index)
        _ffmpeg(['-i', video['path'], '-an', '-vf',
                 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=25,tpad=stop_mode=clone:stop_duration=' + str(chunk['duration_seconds']),
                 '-t', str(chunk['duration_seconds']), '-c:v', 'libx264', '-pix_fmt', 'yuv420p', target])
        normalized.append(target)
    listing = folder / 'video.concat.txt'
    _concat_list(normalized, listing)
    output = folder / 'final.mp4'
    _ffmpeg(['-f', 'concat', '-safe', '0', '-i', listing, '-i', audio['path'],
             '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'aac', '-movflags', '+faststart', output])
    info = probe(output)
    if not info.get('has_audio') or abs(info['duration_seconds'] - audio['duration_seconds']) > 0.5:
        raise RenderBlocked('final_media_sync_check_failed')
    return dict(path=str(output), checksum=sha256_file(output), media_info=info,
                duration_seconds=info['duration_seconds'], audio_hash=audio['audio_hash'],
                native_resolution=False, alignment_evidence=alignment_evidence,
                actual_trims=[dict(turn_id=e['turn_id'], **e['allowed_trim']) for e in alignment_evidence],
                note='1280x720 export; provider native dimensions are recorded per segment; original provider videos retained')


def _scripts(source, base):
    paths = source.get('script_paths') or source.get('script_path') or []
    if isinstance(paths, dict):
        paths = list(paths.values())
    if isinstance(paths, str):
        paths = [paths]
    return [read_json(resolve_path(base, p)) for p in paths]


def _permission(speaker, base):
    permission = speaker.get('permission') or {}
    if not permission.get('proof_ref') or not permission.get('allowed_uses'):
        raise RenderBlocked('missing_permission: ' + speaker['speaker_id'])
    uses = permission['allowed_uses']
    # Require each sensitive use explicitly, with private_test accepted as the
    # complete project scope only if the configuration says so.
    if not isinstance(uses, list) or not {'voice_clone', 'synthetic_video', 'private_test'}.issubset(set(uses)):
        raise RenderBlocked('permission_scope_incomplete: voice_clone, synthetic_video, private_test required')
    proof = resolve_path(base, permission['proof_ref'])
    permission = dict(permission, proof_hash=_hash_path(proof))
    expiry = permission.get('expiry')
    if expiry:
        try:
            expires = datetime.fromisoformat(expiry.replace('Z', '+00:00'))
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if expires <= datetime.now(timezone.utc):
                raise RenderBlocked('permission_expired')
        except (AttributeError, ValueError):
            raise RenderBlocked('permission_expiry_invalid')
    return permission


def _review_covers(ranges, duration):
    if not isinstance(ranges, list) or not ranges:
        return False
    intervals = []
    for pair in ranges:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            return False
        start, end = pair
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in pair) or not 0 <= start < end:
            return False
        intervals.append((start, end))
    cursor = 0.0
    for start, end in sorted(intervals):
        if start > cursor + .05:
            return False
        cursor = max(cursor, end)
    return cursor >= duration - .05


def _calibration_review_approved(review, calibration):
    if not calibration or not isinstance(review, dict):
        return False
    duration = calibration.get('video', {}).get('duration_seconds')
    return (isinstance(duration, (int, float)) and duration > 0 and
            review.get('decision') == 'approved' and review.get('reviewer_type') in ('human', 'model') and
            review.get('scope') == 'private_test' and bool(review.get('review_ref')) and bool(review.get('reviewed_at')) and
            review.get('calibration_hash') == calibration.get('calibration_hash') and
            _review_covers(review.get('watched_ranges_seconds'), duration) and
            _review_covers(review.get('listened_ranges_seconds'), duration))

def _plan_slot(source, kind, identity, script=None):
    version = object_hash({'source': source, 'script_hash': script_hash(script) if script else None})
    return kind + ':' + identity + ':' + version


def _remaining_guard(config, sources, base, pricing, ledger):
    """Protect every remaining language/phase, plus common buffers, per submit.

    Planning allotments are not bills. Measured video costs replace their own
    allotment; other outstanding slots remain protected. Already reserved slots
    are charged by ledger itself and must not be counted a second time here.
    """
    budget = config.get('budget', {})
    buffers = float(budget.get('overhead_reserve_usd', budget.get('overhead_usd', 0))) + float(budget.get('repair_reserve_usd', 0))
    slots = {}
    outputs = config.get('outputs', {})
    for source in sources:
        if source.get('selected') is False:
            continue
        sid = source['source_id']
        scripts = _scripts(source, base)
        if {s.get('purpose') for s in scripts} != {'calibration', 'update'}:
            raise RenderBlocked('complete_two_phase_plan_required: ' + sid)
        for speaker in source.get('speakers', []):
            if not speaker.get('custom_voice_id'):
                slots[_plan_slot(source, 'clone', sid + ':' + speaker['speaker_id'])] = pricing['clone_usd']
        for script in scripts:
            did = script['deliverable_id']
            purpose = script['purpose']
            seconds = float(outputs.get(purpose + '_seconds_per_language', 30 if purpose == 'calibration' else 180))
            # Longer text never reduces the duration planning allocation.
            seconds = max(seconds, float(script.get('target_duration_seconds', 0)))
            total_chars = sum(len(t['text']) for t in script['turns']) or 1
            for turn in script['turns']:
                suffix = did + ':' + turn['turn_id']
                slots[_plan_slot(source, 'tts', suffix, script)] = len(turn['text']) / 1000 * pricing['tts_per_1000_chars_usd']
                slots[_plan_slot(source, 'video', suffix, script)] = seconds * len(turn['text']) / total_chars * pricing['video_per_second_usd']
    def remaining(metadata, upper_bound):
        current = metadata.get('plan_slot')
        covered = {job.get('metadata', {}).get('plan_slot') for job in ledger.jobs() if job['state'] != 'cancelled'}
        floor = buffers + sum(amount for slot, amount in slots.items() if slot != current and slot not in covered)
        return floor
    return remaining

def _resume_only(config, run, ledger):
    """Read-only fal reconciliation remains available despite expired paid gates.

    This never calls reserve/start/submit/upload, even for reserved work. A new
    render invocation is required to advance into additional paid operations.
    """
    path = run / 'media.json'
    manifest = read_json(path) if path.exists() else dict(schema_version=1, route=ROUTE,
        created_at=now(), deliverables=[], actual_media_outputs_verified=False)
    manifest['updated_at'] = now()
    provider = FalProvider()
    report = dict(mode='GET_only', checked_jobs=[], issues=[], new_submissions=0)
    for job in ledger.jobs():
        if job.get('operation') not in ('voice_clone', 'tts', 'avatar_video'):
            continue
        state = job.get('state')
        if state in ('completed', 'succeeded', 'reconciled', 'cancelled', 'reserved'):
            continue
        jid = job['job_id']
        if not job.get('request_id'):
            report['issues'].append('unknown_submission_without_id: ' + jid + '; manual read-only reconciliation required')
            continue
        urls = job.get('urls') or {}
        if not urls.get('status_url') or not urls.get('response_url'):
            report['issues'].append('missing_returned_queue_urls: ' + jid)
            continue
        try:
            status = provider.status(urls['status_url'])
            remote_state = str(status.get('status', '')).upper()
            entry = dict(job_id=jid, request_id=job['request_id'], provider_status=remote_state)
            report['checked_jobs'].append(entry)
            if remote_state == 'COMPLETED':
                result = provider.result(urls['response_url'])
                if not isinstance(result, dict) or result.get('error'):
                    ledger.unknown(jid, 'provider_result_error')
                    report['issues'].append('provider_result_error: ' + jid)
                else:
                    ledger.complete(jid, result)
            elif remote_state in ('FAILED', 'CANCELLED', 'ERROR'):
                ledger.unknown(jid, 'provider_terminal_' + remote_state.lower())
                report['issues'].append('provider_terminal_' + remote_state.lower() + ': ' + jid)
            else:
                report['issues'].append('queued: ' + jid)
        except (ProviderError, OSError, ValueError) as exc:
            report['issues'].append('queue_query_unavailable: ' + jid + ': ' + str(exc))
    manifest['resume'] = report
    manifest['ledger_totals'] = ledger.totals()
    # Do not declare the four actual deliverables complete because their queue
    # results became available. A later render verifies/downloads/assembles them.
    manifest['status'] = 'succeeded' if manifest.get('deliverables') and all(
        d.get('status') == 'succeeded' for d in manifest['deliverables']) and not report['issues'] else 'blocked'
    write_json(path, manifest)
    return manifest

def _render_project(config, base_dir: Path, run_dir: Path, ledger, resume=False):
    base, run = Path(base_dir), Path(run_dir)
    run.mkdir(parents=True, exist_ok=True)
    if resume:
        return _resume_only(config, run, ledger)
    path = run / 'media.json'
    previous = read_json(path) if path.exists() else {}
    manifest = dict(schema_version=1, route=ROUTE, created_at=previous.get('created_at', now()),
                    updated_at=now(), status='blocked', deliverables=[
                        dict(deliverable_id=str(s.get('source_id')) + '_' + purpose, source_id=s.get('source_id'),
                             purpose=purpose, status='blocked', issues=['preflight_not_ready'])
                        for s in config.get('sources', []) if s.get('selected') is not False
                        for purpose in ('calibration', 'update')], issues=[],
                    actual_media_outputs_verified=False)
    # Retain prior artifact references even if today's preflight is blocked.
    for target in manifest['deliverables']:
        prior = next((d for d in previous.get('deliverables', [])
                      if d.get('source_id') == target['source_id'] and d.get('purpose') == target['purpose']), None)
        if prior:
            target.update(prior)
    manifest['actual_media_outputs_verified'] = any(d.get('status') == 'succeeded' for d in manifest['deliverables'])
    provider = FalProvider()
    try:
        pricing = _price_gate(config)
        if not provider.key:
            raise RenderBlocked('missing_credential: FAL_KEY; no paid submission attempted')
        if config.get('synthetic_fixture'):
            raise RenderBlocked('synthetic_fixture_cannot_enter_paid_route')
        models = config.get('models', {})
        endpoints = [models.get('clone_endpoint', ROUTE[0]), models.get('tts_endpoint', ROUTE[1]), models.get('video_endpoint', ROUTE[2])]
        if endpoints != ROUTE:
            raise RenderBlocked('unapproved_media_route')
        ingest = read_json(run / 'ingest.json')
    except (RenderBlocked, OSError, ValueError) as exc:
        manifest['issues'].append(str(exc))
        write_json(path, manifest)
        return manifest
    budget = config.get('budget', {})
    try:
        remaining = _remaining_guard(config, config.get('sources', []), base, pricing, ledger)
    except (RenderBlocked, OSError, ValueError, KeyError) as exc:
        manifest['issues'].append(str(exc))
        write_json(path, manifest)
        return manifest
    poll = min(float(config.get('poll_seconds', 0)), 30)
    ingest_map = {s['source_id']: s for s in ingest.get('sources', [])}
    previous_map = {d['deliverable_id']: d for d in previous.get('deliverables', [])}
    manifest['deliverables'] = []
    human_reviews_path = run / 'calibration_reviews.json'
    human_reviews = read_json(human_reviews_path) if human_reviews_path.exists() else {}
    for source in config.get('sources', []):
        if source.get('selected') is False:
            continue
        sid = source.get('source_id')
        try:
            asset = ingest_map.get(sid, {})
            if asset.get('status') != 'ready' or asset.get('synthetic_fixture'):
                raise RenderBlocked('ingest_not_ready: ' + str(sid))
            source_hash = _hash_path(asset['local_path'], asset.get('file_hash'))
            loaded, _, evidence = _inputs(source, base)
            scripts = sorted(_scripts(source, base), key=lambda s: 0 if s.get('purpose') == 'calibration' else 1)
            if not scripts:
                raise RenderBlocked('missing_reviewed_scripts: ' + str(sid))
            speakers = {s['speaker_id']: s for s in asset.get('speakers', [])}
            permissions = {key: _permission(s, base) for key, s in speakers.items()}
            voices = {}
            calibration = None
            for script in scripts:
                purpose = script.get('purpose')
                digest = script_hash(script)
                did = script.get('deliverable_id') or str(sid) + '_' + str(purpose)
                deliverable = dict(deliverable_id=did, source_id=sid, purpose=purpose,
                                   script_hash=digest, status='blocked', issues=[])
                manifest['deliverables'].append(deliverable)
                try:
                    problems = validate_script(script, loaded, evidence, config.get('as_of'))
                    if problems:
                        raise RenderBlocked('content_review_blocked: ' + ', '.join(p['code'] for p in problems))
                    if any(not isinstance(t.get('text'), str) or not 1 <= len(t['text']) <= 10000 for t in script['turns']):
                        raise RenderBlocked('tts_prompt_length_invalid: each exact turn must contain 1–10000 characters')
                    if purpose == 'update':
                        approval = human_reviews.get(sid, {})
                        if not _calibration_review_approved(approval, calibration):
                            raise RenderBlocked('calibration_review_required: real independent model/human review must cover exact current calibration audio and video')
                    specs = {}
                    for speaker_id in {t['speaker_id'] for t in script['turns']}:
                        speaker = speakers[speaker_id]
                        image = resolve_path(base, speaker['image_ref'])
                        reference = resolve_path(base, speaker['reference_audio_ref'])
                        ih = _hash_path(image, speaker.get('image_hash'))
                        ah = _hash_path(reference, speaker.get('reference_audio_hash'))
                        specs[speaker_id] = dict(source_hash=source_hash, speaker_id=speaker_id,
                                                 permission=permissions[speaker_id], image_hash=ih, reference_audio_hash=ah)
                        if speaker_id not in voices:
                            if speaker.get('custom_voice_id'):
                                # Supplied existing voices must be tied to these exact assets.
                                if speaker.get('voice_reference_hash') != ah or not speaker.get('voice_verified_at'):
                                    raise RenderBlocked('existing_voice_unverified: ' + speaker_id)
                                voices[speaker_id] = speaker['custom_voice_id']
                            else:
                                clone_spec = dict(specs[speaker_id], endpoint=ROUTE[0], settings={'text': None})
                                result = run_job(provider, ledger, 'voice_clone', object_hash(clone_spec), pricing['clone_usd'], ROUTE[0],
                                    lambda ref=reference: {'audio_url': provider.upload(ref), 'text': None},
                                    metadata=dict(clone_spec, plan_slot=_plan_slot(source, 'clone', sid + ':' + speaker_id)), minimum_remaining=remaining, poll_seconds=poll)
                                voice = result.get('custom_voice_id')
                                if not voice:
                                    raise RenderBlocked('clone_result_missing_custom_voice_id')
                                voices[speaker_id] = voice
                    # Spec-addressed directories avoid overwriting old successful artifacts.
                    full_spec = dict(script_hash=digest, speakers=specs, voices=voices, source_hash=source_hash,
                                     endpoint=ROUTE[1], settings={'language_boost': 'Chinese' if source['language'] == 'zh' else 'English', 'output_format': 'url'})
                    spec_hash = object_hash(full_spec)
                    folder = run / 'media' / _safe(did) / spec_hash
                    folder.mkdir(parents=True, exist_ok=True)
                    old = previous_map.get(did, {})
                    if old.get('spec_hash') == spec_hash and old.get('status') == 'succeeded':
                        if all(_cached_artifact(a['path'], a['checksum']) for a in (old['audio'], old['video'])) and all(
                                _cached_artifact(c['path'], c['checksum']) for c in old['audio']['chunks']):
                            deliverable.update(old)
                            if purpose == 'calibration':
                                calibration = deliverable
                            continue
                        raise RenderBlocked('cached_artifact_changed: new explicit attempt required')
                    deliverable['spec_hash'] = spec_hash
                    parts = []
                    for index, turn in enumerate(script['turns']):
                        payload = dict(prompt=turn['text'], voice_setting={'voice_id': voices[turn['speaker_id']]}, **full_spec['settings'])
                        tts_spec = dict(full_spec, turn=turn, endpoint=ROUTE[1])
                        result = run_job(provider, ledger, 'tts', object_hash(tts_spec),
                                         len(turn['text']) / 1000 * pricing['tts_per_1000_chars_usd'], ROUTE[1],
                                         lambda p=payload: p, metadata=dict(tts_spec, plan_slot=_plan_slot(source, 'tts', did + ':' + turn['turn_id'], script)), minimum_remaining=remaining, poll_seconds=poll)
                        target = folder / ('tts_%03d.mp3' % index)
                        part = _download(provider, result, 'audio', target)
                        part.update(turn_id=turn['turn_id'], speaker_id=turn['speaker_id'])
                        parts.append(part)
                    freeze_path = folder / 'audio.json'
                    if freeze_path.exists():
                        frozen = read_json(freeze_path)
                        if not _cached_artifact(frozen['path'], frozen['checksum']) or any(not _cached_artifact(c['path'], c['checksum']) for c in frozen['chunks']):
                            raise RenderBlocked('frozen_audio_changed: cannot reuse old video with replacement audio')
                    else:
                        frozen = _freeze_audio(parts, folder, digest)
                        write_json(freeze_path, frozen)
                    deliverable['audio'] = frozen
                    videos = []
                    for index, chunk in enumerate(frozen['chunks']):
                        speaker_id = chunk['speaker_id']
                        image = resolve_path(base, speakers[speaker_id]['image_ref'])
                        video_spec = dict(full_spec, endpoint=ROUTE[2], image_hash=specs[speaker_id]['image_hash'],
                                          audio_hash=chunk['checksum'], frozen_audio_hash=frozen['audio_hash'],
                                          turn_id=chunk['turn_id'], settings={'prompt': AVATAR_PROMPT})
                        result = run_job(provider, ledger, 'avatar_video', object_hash(video_spec),
                                         chunk['duration_seconds'] * pricing['video_per_second_usd'], ROUTE[2],
                                         lambda image=image, chunk=chunk: {'image_url': provider.upload(image), 'audio_url': provider.upload(chunk['path']), 'prompt': AVATAR_PROMPT},
                                         metadata=dict(video_spec, plan_slot=_plan_slot(source, 'video', did + ':' + chunk['turn_id'], script)), minimum_remaining=remaining, poll_seconds=poll)
                        target = folder / ('avatar_%03d.mp4' % index)
                        video = _download(provider, result, 'video', target)
                        videos.append(video)
                    deliverable['segments'] = videos
                    deliverable['video'] = _assemble(videos, frozen, folder)
                    deliverable['status'] = 'succeeded'
                    if purpose == 'calibration':
                        deliverable['calibration_hash'] = object_hash({'script_hash': digest, 'audio_hash': frozen['audio_hash'],
                                                                      'video_hash': deliverable['video']['checksum'], 'spec_hash': spec_hash})
                        calibration = deliverable
                except (RenderBlocked, ProviderError, OSError, ValueError, KeyError, RuntimeError) as exc:
                    deliverable['issues'].append(str(exc))
                write_json(path, manifest)
        except (RenderBlocked, OSError, ValueError, KeyError, RuntimeError) as exc:
            manifest['issues'].append(str(exc))
    present = {(d.get('source_id'), d.get('purpose')) for d in manifest['deliverables']}
    for source in config.get('sources', []):
        if source.get('selected') is False:
            continue
        for purpose in ('calibration', 'update'):
            if (source.get('source_id'), purpose) not in present:
                manifest['deliverables'].append(dict(deliverable_id=str(source.get('source_id')) + '_' + purpose,
                    source_id=source.get('source_id'), purpose=purpose, status='blocked',
                    issues=['source_dependencies_blocked: see project issues']))
    manifest['status'] = 'succeeded' if manifest['deliverables'] and all(d['status'] == 'succeeded' for d in manifest['deliverables']) and not manifest['issues'] else 'blocked'
    manifest['actual_media_outputs_verified'] = any(d['status'] == 'succeeded' for d in manifest['deliverables'])
    manifest['ledger_totals'] = ledger.totals()
    write_json(path, manifest)
    return manifest


def render_project(config, base_dir: Path, run_dir: Path, ledger, resume=False):
    """Prevent CLI/UI processes from racing on freeze manifests and media files."""
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    with (run_dir / 'media.lock').open('a') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return dict(status='blocked', issues=['another_media_operation_running'], new_submissions=0)
        try:
            return _render_project(config, base_dir, run_dir, ledger, resume=resume)
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
