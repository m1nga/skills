"""Explicit GET-only billing reconciliation; estimates never become actual bills."""
from decimal import Decimal, InvalidOperation
import os
from pathlib import Path
import re

from .providers import FalProvider
from .util import now, object_hash, write_json, sha256_file


class BillingUnresolved(ValueError):
    pass


def _cost(value):
    if value is None or isinstance(value, bool):
        raise BillingUnresolved('Missing real cost_total')
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise BillingUnresolved('Invalid real cost_total')
    if not result.is_finite() or result < 0:
        raise BillingUnresolved('Invalid real cost_total')
    return result


def _exact_request_cost(response, request_id):
    """Accept only explicit cost_total records tied to the original request.

    A zero balance, an estimate, quantities*prices, or an empty result cannot
    establish a zero bill. Partial/paginated responses remain unresolved.
    """
    if not isinstance(response, dict):
        raise BillingUnresolved('Unrecognized billing response')
    if any(response.get(k) for k in ('next_cursor', 'next_page_token', 'has_more')):
        raise BillingUnresolved('Paginated billing response is incomplete')
    if response.get('request_id') == request_id and 'cost_total' in response:
        if response.get('status') in ('pending', 'estimated', 'provisional') or response.get('currency', 'USD') != 'USD':
            raise BillingUnresolved('Top-level billing is provisional or not USD')
        return _cost(response['cost_total'])
    events = None
    for key in ('billing_events', 'events', 'items', 'data'):
        if isinstance(response.get(key), list):
            events = response[key]
            break
    if events is None:
        raise BillingUnresolved('No billable event records')
    matching = [event for event in events if isinstance(event, dict) and event.get('request_id') == request_id]
    if not matching:
        raise BillingUnresolved('No exact request_id billing match')
    total = Decimal('0')
    seen = {}
    for event in matching:
        # Events without identifiers are still content-deduplicated. Different
        # events sharing an ID with different costs are contradictory evidence.
        identity = event.get('event_id') or event.get('id') or object_hash(event)
        cost = _cost(event.get('cost_total'))
        if identity in seen:
            if seen[identity] != cost:
                raise BillingUnresolved('Conflicting duplicate billing event')
            continue
        if event.get('status') in ('pending', 'estimated', 'provisional'):
            raise BillingUnresolved('Billing event is not final')
        currency = event.get('currency', 'USD')
        if currency != 'USD':
            raise BillingUnresolved('Billing currency is not USD')
        seen[identity] = cost
        total += cost
    return total


def reconcile_project(ledger, provider=None, run_dir=None):
    """Read actual request bills and preserve missing/inaccessible reservations.

    Raw returned receipts stay in private run/receipts/billing. The report
    references only a local receipt and hash; it includes no signed URLs or key.
    Billing key fallback never creates/expands credentials or model jobs.
    """
    provider = provider or FalProvider(key=os.environ.get('FAL_BILLING_KEY') or os.environ.get('FAL_KEY'))
    report = dict(created_at=now(), mode='GET_only', new_submissions=0, reconciled=[], unresolved=[])
    for job in ledger.jobs():
        if job.get('actual_cost') is not None or job.get('state') in ('reserved', 'cancelled'):
            continue
        jid, request_id = job['job_id'], job.get('request_id')
        if not request_id:
            report['unresolved'].append(dict(job_id=jid, reason='missing_original_request_id'))
            continue
        # Only the fal media route is owned here. ASR and research require their
        # own true receipts and must not query fal with unrelated request IDs.
        if job.get('operation') not in ('voice_clone', 'tts', 'avatar_video'):
            report['unresolved'].append(dict(job_id=jid, reason='non_fal_receipt_required'))
            continue
        try:
            raw = provider.billing_events(request_id)
            digest = object_hash(raw)
            if run_dir is not None:
                folder = Path(run_dir) / 'receipts' / 'billing'
                folder.mkdir(parents=True, exist_ok=True, mode=0o700)
                safe_id = re.sub(r'[^A-Za-z0-9_-]', '_', request_id)[:100]
                receipt = folder / (safe_id + '-' + digest + '.json')
                write_json(receipt, raw)
                receipt.chmod(0o600)
                digest = sha256_file(receipt)
                receipt_ref = str(receipt.resolve()) + '#sha256=' + digest
            else:
                receipt_ref = 'fal:billing-events:' + request_id + '#sha256=' + digest
            amount = _exact_request_cost(raw, request_id)
            ledger.reconcile(jid, float(amount), receipt_ref)
            report['reconciled'].append(dict(job_id=jid, request_id=request_id,
                                               actual_cost_usd=float(amount), receipt_ref=receipt_ref))
        except Exception as exc:
            # Error bodies may contain private provider URLs. Public output
            # records a category; raw successful responses are private above.
            report['unresolved'].append(dict(job_id=jid, reason=type(exc).__name__,
                                                recovery='Read original request billing receipt; do not resubmit'))
    report['status'] = 'blocked' if report['unresolved'] else 'succeeded'
    report['ledger_totals'] = ledger.totals()
    if run_dir is not None:
        write_json(Path(run_dir) / 'billing.json', report)
    return report
