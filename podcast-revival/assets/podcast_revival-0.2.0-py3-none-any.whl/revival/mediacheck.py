"""Local waveform evidence for trimming an otherwise rejected video tail.

No network, model, numpy or alteration of the driving audio. A correlation
score is an audio alignment measurement, not a lip-sync or likeness rating.
"""
import array
import math
import sys
import wave
from pathlib import Path

from .ingest import _binary, _run, probe


def _decode(path, output):
    binary = _binary('ffmpeg')
    if not binary:
        raise ValueError('missing_ffmpeg')
    _run([binary, '-y', '-v', 'error', '-i', str(path), '-vn', '-ac', '1', '-ar', '1000',
          '-c:a', 'pcm_s16le', str(output)])
    with wave.open(str(output), 'rb') as stream:
        if stream.getnchannels() != 1 or stream.getframerate() != 1000 or stream.getsampwidth() != 2:
            raise ValueError('unexpected_pcm_format')
        samples = array.array('h', stream.readframes(stream.getnframes()))
        if sys.byteorder != 'little':
            samples.byteswap()
    return samples


def _rms(values):
    return math.sqrt(sum(float(x) * x for x in values) / len(values)) if values else 0.0


def _correlation(left, right, minimum=100):
    n = len(left)
    if n < minimum or n != len(right):
        return None
    a, b = sum(left) / n, sum(right) / n
    aa = bb = ab = 0.0
    for x, y in zip(left, right):
        x, y = x - a, y - b
        aa += x * x
        bb += y * y
        ab += x * y
    if aa <= 0 or bb <= 0:
        return None
    return ab / math.sqrt(aa * bb)


def check_tail_padding(video_path, frozen_audio_path, work_dir, *, target_seconds=None):
    """Accept only an aligned complete target followed by a quiet audio tail.

    Search ±100ms; acceptance requires |offset|<=80ms, every target sample,
    either raw correlation>0.90 or raw>=0.60 with independent 20ms RMS
    envelope correlation>=0.98, plus tail RMS <=3% of target-body RMS. Evidence PCM files
    remain with the run so the decision can be independently inspected.
    """
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)
    report = {'status': 'blocked', 'method': 'mono_1000Hz_s16le_normalized_cross_correlation',
              'video_path': str(video_path), 'frozen_audio_path': str(frozen_audio_path),
              'search_seconds': [-.1, .1], 'thresholds': {'correlation_gt': .90, 'absolute_offset_lte_seconds': .08,
                   'tail_rms_ratio_lte': .03, 'video_tail_seconds': [.5, 2],
                   'alternate_raw_correlation_gte': .60, 'envelope_correlation_gte': .98,
                   'envelope_window_ms': 20, 'minimum_envelope_windows': 20}, 'issues': []}
    try:
        video_info, target_info = probe(video_path), probe(frozen_audio_path)
        target_duration = float(target_seconds if target_seconds is not None else target_info['duration_seconds'])
        extra = video_info['duration_seconds'] - target_duration
        report.update(video_duration_seconds=video_info['duration_seconds'], target_duration_seconds=target_duration,
                      extra_video_seconds=extra)
        if not .5 < extra <= 2:
            report['issues'].append('video_difference_outside_verifiable_tail_padding_range')
            return report
        if not video_info.get('has_audio'):
            report['issues'].append('original_video_has_no_audio')
            return report
        target = _decode(frozen_audio_path, work / 'frozen-1000hz.wav')
        video = _decode(video_path, work / 'video-1000hz.wav')
        report['pcm_paths'] = {'frozen': str(work / 'frozen-1000hz.wav'), 'video': str(work / 'video-1000hz.wav')}
        if len(target) < 100 or _rms(target) < 1:
            report['issues'].append('target_audio_has_insufficient_signal_for_alignment')
            return report
        candidates = []
        for offset in range(-100, 101):
            start = max(0, offset)
            target_start = max(0, -offset)
            n = min(len(target) - target_start, len(video) - start)
            if n <= 0:
                continue
            score = _correlation(target[target_start:target_start+n], video[start:start+n])
            if score is not None:
                candidates.append((score, -abs(offset), offset, n, target_start))
        if not candidates:
            report['issues'].append('no_comparable_audio_signal')
            return report
        score, _, offset, n, target_start = max(candidates)
        start = max(0, offset)
        left = target[target_start:target_start+n]
        right = video[start:start+n]
        target_envelope = [_rms(left[i:i+20]) for i in range(0, n, 20)]
        video_envelope = [_rms(right[i:i+20]) for i in range(0, n, 20)]
        # This independent metric deliberately permits fewer than the 100
        # waveform samples required by _correlation's default guard.
        envelope_score = _correlation(target_envelope, video_envelope, minimum=20)
        raw_route = score > .90
        envelope_route = score >= .60 and envelope_score is not None and envelope_score >= .98
        tail_start = offset + len(target)
        tail = video[max(0, tail_start):]
        body_rms, tail_rms = _rms(target), _rms(tail)
        report.update(correlation=score, energy_envelope_correlation=envelope_score,
                      energy_envelope_windows=len(target_envelope),
                      alignment_route='raw_waveform' if raw_route else 'waveform_plus_energy_envelope' if envelope_route else None,
                      offset_seconds=offset/1000,
                      target_samples=len(target), compared_samples=n,
                      target_coverage=n/len(target), target_start_sample=target_start,
                      target_rms=body_rms, tail_rms=tail_rms, tail_rms_ratio=tail_rms/body_rms,
                      tail_audio_seconds=len(tail)/1000,
                      video_audio_seconds=len(video)/1000)
        if not (raw_route or envelope_route):
            report['issues'].append('audio_alignment_not_verified_by_either_strict_route')
        if abs(offset) > 80:
            report['issues'].append('audio_start_offset_exceeds_80ms')
        if target_start != 0 or n != len(target):
            report['issues'].append('original_video_audio_does_not_cover_complete_target')
        if tail_rms > body_rms * .03:
            report['issues'].append('video_tail_contains_non_silent_audio')
        if not report['issues']:
            report['status'] = 'verified_tail_padding'
            report['allowed_trim'] = {'start_seconds': 0, 'end_seconds': target_duration,
                                      'removed_tail_seconds': extra,
                                      'audio_policy': 'mux_original_frozen_audio_without_retiming'}
    except (OSError, ValueError, RuntimeError, KeyError, wave.Error) as exc:
        report['issues'].append('local_audio_check_failed:' + type(exc).__name__ + ':' + str(exc))
    return report
