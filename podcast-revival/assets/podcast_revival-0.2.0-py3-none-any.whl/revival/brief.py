"""Offline production-brief intake. No credentials, providers or model calls."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

TONES = ('curious', 'balanced', 'skeptical', 'constructive', 'warm')
MAX_DURATION_SECONDS = 86400


def _text(value, field, default=''):
    if value is None:
        return default
    if not isinstance(value, str):
        raise ValueError(f'{field} must be text.')
    return value.strip()


def _duration(value):
    if isinstance(value, bool):
        raise ValueError('Duration must be an integer number of seconds.')
    try:
        result = int(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError('Duration must be an integer number of seconds.') from None
    if isinstance(value, float) and value != result:
        raise ValueError('Duration must be an integer number of seconds.')
    if result < 1 or result > MAX_DURATION_SECONDS:
        raise ValueError('Duration must be between 1 and 86400 seconds. This is a planning target, not a production authorization.')
    return result


def _material(path):
    resolved = Path(path).expanduser().resolve(strict=True)
    if not resolved.is_file():
        raise ValueError(f'Material must be a file: {resolved}')
    return {'path': str(resolved), 'name': resolved.name, 'bytes': resolved.stat().st_size,
            'access': 'local_file_reference', 'contents_copied': False}


def create_brief(*, out, input_path=None, text_file=None, duration=None, tone=None,
                 viewpoint=None, materials=None) -> dict:
    """Create a new local project folder, leaving existing folders untouched.

    Website files contain metadata only. Actual materials can be attached with
    --material; unresolved names remain explicit next-step dependencies. An URL
    remains an unfetched source reference. No render config is fabricated.
    """
    output = Path(out).expanduser().resolve()
    if output.exists():
        raise ValueError(f'Output already exists; choose a new directory: {output}')
    raw = {}
    input_ref = None
    if input_path:
        input_ref = Path(input_path).expanduser().resolve(strict=True)
        raw = json.loads(input_ref.read_text(encoding='utf-8'))
        if not isinstance(raw, dict) or raw.get('schema_version') != 1 or raw.get('kind') != 'revival_production_brief':
            raise ValueError('Input must be a Revival website production brief with schema_version 1.')
        if raw.get('status') != 'local_draft_not_submitted':
            raise ValueError('Website brief status must be local_draft_not_submitted.')
    source = raw.get('source', {})
    direction = raw.get('direction', {})
    if not isinstance(source, dict) or not isinstance(direction, dict):
        raise ValueError('Website source and direction must be objects.')
    _text(source.get('supplied_text'), 'source.supplied_text')  # Validate type without trimming the original.
    source_text = source.get('supplied_text') or ''
    text_ref = None
    if text_file:
        text_ref = Path(text_file).expanduser().resolve(strict=True)
        if not text_ref.is_file():
            raise ValueError('Text source must be a UTF-8 file.')
        source_text = text_ref.read_text(encoding='utf-8')
        if not source_text.strip():
            raise ValueError('Text source is empty.')
    source_url = _text(source.get('url'), 'source.url')
    if source_url:
        parsed = urlparse(source_url)
        if parsed.scheme not in ('https', 'http') or not parsed.hostname:
            raise ValueError('Source URL must use http:// or https://.')
    listed = source.get('local_materials', [])
    if not isinstance(listed, list):
        raise ValueError('source.local_materials must be a list.')
    unresolved = []
    for item in listed:
        if not isinstance(item, dict) or not _text(item.get('name'), 'material.name'):
            raise ValueError('Each website material needs a filename.')
        count = item.get('bytes')
        if not isinstance(count, int) or isinstance(count, bool) or count < 0:
            raise ValueError('Website material size must be a nonnegative integer.')
        unresolved.append({'name': item['name'], 'bytes': count, 'reason': 'Website brief contains metadata, not the original file.'})
    actual = [_material(path) for path in (materials or [])]
    # Filenames and byte counts alone cannot establish that files are identical.
    # Keep a potential match visible for host verification instead of silently
    # marking the browser-only file reference as resolved.
    for item in unresolved:
        item['candidate_paths'] = [m['path'] for m in actual if m['name'] == item['name'] and m['bytes'] == item['bytes']]
    if not source_text.strip() and not source_url and not actual and not unresolved:
        raise ValueError('Provide source text, a source URL, or material files. A creative direction alone is not source material.')
    target = _duration(duration if duration is not None else direction.get('target_seconds', 180))
    attitude = _text(tone if tone is not None else direction.get('attitude', 'curious'), 'attitude')
    if attitude not in TONES:
        raise ValueError('Attitude must be one of: ' + ', '.join(TONES))
    question = _text(viewpoint if viewpoint is not None else direction.get('editorial_question_or_viewpoint'), 'viewpoint')
    if not question:
        raise ValueError('Provide the question or point of view to explore with --viewpoint or in the website brief.')
    language = _text(direction.get('language', 'source'), 'language')
    if language not in ('source', 'en', 'zh', 'other'):
        raise ValueError('Language must be source, en, zh, or other.')
    constraints = _text(direction.get('constraints'), 'constraints')
    if language == 'other' and not constraints:
        raise ValueError('Specify the desired language in the website constraints field.')
    status = ('material_resolution_needed' if unresolved and not (source_text.strip() or actual or source_url)
              else 'source_url_unfetched' if source_url and not (source_text.strip() or actual)
              else 'material_available_for_inspection')
    next_step = (
        'Host agent: obtain the original files named in source.unresolved_materials before inspecting their content.'
        if status == 'material_resolution_needed' else
        'Host agent: inspect the supplied source material (fetch the URL if present), identify its central questions and actual speakers, then propose an evidence-bound outline for the requested duration, stance and viewpoint.'
    )
    normalized = {
        'schema_version': 1, 'kind': 'revival_normalized_brief', 'status': 'brief_ready',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'title': _text(raw.get('title'), 'title') or 'Untitled continuation',
        'duration_seconds': target, 'stance': attitude, 'viewpoint': question,
        'language': language, 'constraints': constraints or None,
        'source': {'text_path': 'source.txt' if source_text.strip() else None,
                   'original_text_path': str(text_ref) if text_ref else None,
                   'source_url': source_url or None, 'url_fetched': False,
                   'material_paths': actual, 'unresolved_materials': unresolved,
                   'status': status},
        'input_brief_path': str(input_ref) if input_ref else None,
        'input_brief_sha256': hashlib.sha256(input_ref.read_bytes()).hexdigest() if input_ref else None,
        'renderable_config': None,
        'next_step': next_step,
        'host_tasks': [
            'Distinguish supplied source statements, new evidence and AI-authored material.',
            'Preserve uncertainties, original attribution and source times; do not invent personal experiences or endorsements.',
            'Draft in the requested language and attitude, then obtain independent review bound to the actual script.',
            'Use the existing runtime only after material permissions, speaker/reference mapping, exact-script review, provider pricing and an explicit budget are established.',
            'Treat the requested duration as a creative target. This intake imposes no two-language or three-minute pilot requirement.'
        ],
        'execution': {'paid_calls': 0, 'model_calls': 0, 'source_analysis_performed': False,
                      'budget_authorization': None, 'generation_submitted': False,
                      'publication_authorized': False}
    }
    # Validate all inputs before making the first filesystem mutation. mkdir is
    # exclusive, so a concurrent intake cannot overwrite another project.
    output.mkdir(parents=True, exist_ok=False)
    if input_ref:
        (output / 'website-brief.original.json').write_bytes(input_ref.read_bytes())
    if source_text.strip():
        (output / 'source.txt').write_text(source_text, encoding='utf-8')
    (output / 'brief.json').write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'NEXT_STEP.md').write_text(
        '# Revival production brief\n\nStatus: brief_ready — source inspection and production have not run.\n\n' +
        next_step + '\n\n## Source material\n\n' +
        ('Preserved text: source.txt\n\n' if source_text.strip() else '') +
        ('Original text file: ' + str(text_ref) + '\n\n' if text_ref else '') +
        ('Source URL (not fetched): ' + source_url + '\n\n' if source_url else '') +
        ''.join('- Local file: ' + m['path'] + ' (' + str(m['bytes']) + ' bytes)\n' for m in actual) +
        ''.join('- Reconnect original file: ' + m['name'] + ' (' + str(m['bytes']) + ' bytes); candidates: ' + (', '.join(m['candidate_paths']) or 'none') + '\n' for m in unresolved) +
        '\n## Host work\n\n' + '\n'.join('- ' + task for task in normalized['host_tasks']) +
        '\n\nNo renderable project config, paid request, budget authorization or publication was created.\n', encoding='utf-8')
    return {'status': 'brief_ready', 'project_dir': str(output), 'brief_path': str(output / 'brief.json'),
            'source_status': status, 'next_step': next_step, 'renderable_config': None, 'paid_calls': 0}
