"""Authenticated fal price verification without any generation or paid probe.

Schema checked against https://fal.ai/docs/platform-apis/v1/models/pricing .
The API's unit is model-specific; a generic `video` does not mean `second`.
"""
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone
from pathlib import Path
import re

from .providers import FalProvider
from .util import now, object_hash, write_json, sha256_file

PRICING_DOC = 'https://fal.ai/docs/platform-apis/v1/models/pricing'
ROUTE = {
    'clone_endpoint': ('fal-ai/minimax/voice-clone', 'clone_usd'),
    'tts_endpoint': ('fal-ai/minimax/speech-2.8-hd', 'tts_per_1000_chars_usd'),
    'video_endpoint': ('fal-ai/kling-video/ai-avatar/v2/pro', 'video_per_second_usd'),
}


class PriceUnverified(ValueError):
    pass


def _clone_documented_unit(endpoint, evidence):
    """Resolve fal's generic clone `units` using fresh exact-endpoint evidence.

    This only establishes one clone request per billing unit. The account API
    remains the source of the actual unit price (including account discounts).
    """
    url = 'https://fal.ai/models/fal-ai/minimax/voice-clone'
    if endpoint != 'fal-ai/minimax/voice-clone' or not isinstance(evidence, dict):
        raise PriceUnverified('clone_generic_unit_needs_primary_evidence')
    if evidence.get('unit') != 'request' or evidence.get('source_url') != url:
        raise PriceUnverified('clone_unit_evidence_identity_mismatch')
    try:
        stamp = datetime.fromisoformat(evidence['verified_at'].replace('Z', '+00:00'))
        if stamp.tzinfo is None:
            raise ValueError('Evidence timestamp needs timezone')
        current = datetime.now(timezone.utc)
        if stamp.astimezone(timezone.utc).date() != current.date() or (stamp - current).total_seconds() > 300:
            raise ValueError('Evidence not current')
    except (KeyError, TypeError, ValueError, AttributeError):
        raise PriceUnverified('clone_unit_evidence_not_current')
    text = evidence.get('supporting_text')
    if not isinstance(text, str) or not re.search(r'each\s+voice\s+clone\s+request\s+will\s+cost\s+\$\s*\d+(?:\.\d+)?', text, flags=re.I):
        raise PriceUnverified('clone_unit_evidence_missing_per_request_statement')
    return dict(unit='request', source_url=url, verified_at=evidence['verified_at'],
                supporting_text=text, evidence_hash=object_hash(evidence))


def _normalise_price(response, endpoint, setting, unit_evidence=None):
    if not isinstance(response, dict) or not isinstance(response.get('prices'), list):
        raise PriceUnverified('pricing_schema_unrecognized')
    if response.get('has_more') is not False or response.get('next_cursor') is not None:
        raise PriceUnverified('pricing_response_incomplete')
    # The exact selection must have one unambiguous quote. An unrelated price
    # must never substitute for an endpoint alias/parent model.
    quotes = [q for q in response['prices'] if isinstance(q, dict) and q.get('endpoint_id') == endpoint]
    if len(quotes) != 1:
        raise PriceUnverified('exact_endpoint_price_missing_or_ambiguous')
    quote = quotes[0]
    if quote.get('currency') != 'USD':
        raise PriceUnverified('pricing_currency_not_USD')
    amount = quote.get('unit_price')
    # Official schema is numeric; numeric strings are not silently accepted.
    if isinstance(amount, bool) or not isinstance(amount, (int, float)):
        raise PriceUnverified('unit_price_not_numeric')
    try:
        value = Decimal(str(amount))
    except InvalidOperation:
        raise PriceUnverified('unit_price_invalid')
    if not value.is_finite() or value <= 0:
        raise PriceUnverified('positive_price_bound_unavailable')
    unit = quote.get('unit')
    if not isinstance(unit, str):
        raise PriceUnverified('billing_unit_missing')
    token = re.sub(r'[ _-]+', ' ', unit.strip().lower())
    documentation_evidence = None
    if setting == 'clone_usd':
        if token in ('unit', 'units'):
            documentation_evidence = _clone_documented_unit(endpoint, unit_evidence)
            token = 'request'
        if token not in ('request', 'requests', 'call', 'calls', 'voice', 'voice clone', 'clone'):
            raise PriceUnverified('clone_unit_semantics_unverified: ' + unit)
        normalized = value
        target_unit = 'request'
    elif setting == 'tts_per_1000_chars_usd':
        if token in ('character', 'characters', 'char', 'chars'):
            normalized = value * 1000
        elif token in ('1000 character', '1000 characters', '1000 char', '1000 chars', '1k characters', '1k chars'):
            normalized = value
        else:
            raise PriceUnverified('tts_unit_semantics_unverified: ' + unit)
        target_unit = '1000_characters'
    else:
        if token not in ('second', 'seconds', 'video second', 'video seconds', 'output second', 'output seconds'):
            raise PriceUnverified('video_unit_semantics_unverified: ' + unit)
        normalized = value
        target_unit = 'second'
    return dict(endpoint_id=endpoint, currency='USD', unit=unit, unit_price=amount,
                normalized_unit=target_unit, normalized_unit_price=float(normalized), config_field=setting,
                unit_basis='exact_endpoint_primary_documentation' if documentation_evidence else 'authenticated_explicit_billing_unit',
                unit_evidence=documentation_evidence)


def verify_pricing(config, run_dir, provider=None):
    """Return config-safe current quotes; caller explicitly persists a success.

    Does not mutate config. No key means no GET. A failed refresh returns
    account_verified=false so an earlier successful snapshot is not reused as
    today's verification. Public list prices can never set account_verified.
    """
    provider = provider or FalProvider()
    stamp = now()
    result = dict(created_at=stamp, status='blocked', mode='GET_only', new_submissions=0,
                  account_verified=False, quotes=[], issues=[], source=PRICING_DOC,
                  pricing={'account_verified': False})
    run = Path(run_dir)
    run.mkdir(parents=True, exist_ok=True)
    if not provider.key:
        result['issues'].append('missing_credential: FAL_KEY; pricing GET not attempted')
        write_json(run / 'pricing.json', result)
        return result
    selected = []
    for config_key, (default_endpoint, field) in ROUTE.items():
        endpoint = config.get('models', {}).get(config_key, default_endpoint)
        if endpoint != default_endpoint:
            result['issues'].append('unapproved_media_endpoint: ' + str(endpoint))
        selected.append((endpoint, field))
    if result['issues']:
        write_json(run / 'pricing.json', result)
        return result
    for endpoint, field in selected:
        try:
            raw = provider.pricing(endpoint)
            # Store raw evidence separately, even if its units are uninterpretable.
            folder = run / 'receipts' / 'pricing'
            folder.mkdir(parents=True, exist_ok=True, mode=0o700)
            raw_path = folder / (object_hash({'endpoint': endpoint, 'retrieved_at': stamp, 'response': raw}) + '.json')
            unit_evidence = config.get('pricing_unit_evidence', {}).get(endpoint)
            write_json(raw_path, dict(endpoint_id=endpoint, retrieved_at=stamp, response=raw, unit_evidence=unit_evidence))
            raw_path.chmod(0o600)
            quote = _normalise_price(raw, endpoint, field, unit_evidence=unit_evidence)
            quote['receipt_ref'] = str(raw_path.resolve()) + '#sha256=' + sha256_file(raw_path)
            result['quotes'].append(quote)
        except PriceUnverified as exc:
            result['issues'].append(dict(endpoint_id=endpoint, reason=str(exc)))
        except Exception as exc:
            # Never include private HTTP exception bodies/headers in UI reports.
            result['issues'].append(dict(endpoint_id=endpoint, reason=type(exc).__name__, recovery='Retry authenticated pricing GET; do not generate a paid probe'))
    if len(result['quotes']) == len(ROUTE) and not result['issues']:
        result['status'] = 'ready'
        result['account_verified'] = True
        result['pricing'] = dict(account_verified=True, verified_at=stamp,
                                basis='Authenticated fal account pricing, exact endpoint and billing-unit verification',
                                sources=[PRICING_DOC], quote_refs=[q['receipt_ref'] for q in result['quotes']])
        for quote in result['quotes']:
            result['pricing'][quote['config_field']] = quote['normalized_unit_price']
    write_json(run / 'pricing.json', result)
    return result
