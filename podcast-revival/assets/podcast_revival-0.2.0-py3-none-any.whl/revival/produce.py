"""Single-language production from a host-authored, reviewed script.

Dry-run is the default. Stock voices are synthesis voices, not speaker clones.
This adapter reuses the pilot's provider, durable ledger and media primitives;
it does not inherit the pilot's bilingual/calibration experiment contract.
"""
import fcntl
import math
import json
import os
import tempfile
from pathlib import Path

from .content import script_hash
from .ledger import Ledger
from .pricing import _normalise_price
from .providers import FalProvider
from .render import (ROUTE, AVATAR_PROMPT, RenderBlocked, run_job, _download,
                     _freeze_audio, _assemble, _cached_artifact)
from .util import read_json, write_json, object_hash, sha256_file, now, resolve_path

DEFAULT_STOCK_VOICE = 'Wise_Woman'


def _positive(value, field):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(field + ' must be a positive finite number.')
    return float(value)


def _proof(base, reference, expected=None):
    if not isinstance(reference, str) or not reference.strip():
        raise ValueError('proof_ref_must_name_an_existing_file')
    path = resolve_path(base, reference)
    if not path.is_file():
        raise ValueError('proof_file_missing:' + str(path))
    checksum = sha256_file(path)
    if expected and expected != checksum:
        raise ValueError('proof_file_hash_changed:' + str(path))
    return {'path': str(path), 'checksum': checksum}


def _private_json(path, value):
    """Create private snapshots as 0600 before writing their first byte."""
    path = Path(path)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, prefix='.private-', delete=False) as stream:
        temporary = Path(stream.name)
        try:
            os.chmod(temporary, 0o600)
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
    os.replace(temporary, path)


def _resume_existing(run, provider):
    """Recover historical requests independently of current sources/approval."""
    identity_path, ledger_path = run / 'production.identity.json', run / 'ledger.sqlite'
    if not identity_path.is_file() or not ledger_path.is_file():
        return {'status': 'blocked', 'mode': 'GET_only', 'issues': ['no_existing_production_to_resume'], 'new_submissions': 0}
    with open(run / '.production.lock', 'a+') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'status': 'blocked', 'mode': 'GET_only', 'issues': ['production_already_running'], 'new_submissions': 0}
        identity = read_json(identity_path)
        limit = identity.get('budget_limit_usd')
        if limit is None and (run / 'production.json').is_file():
            limit = read_json(run / 'production.json').get('ledger_totals', {}).get('limit_usd')
        # Legacy records may lack a persisted limit. No reserve is possible in
        # this branch; avoid presenting an invented budget in the report.
        ledger = Ledger(ledger_path, 0 if limit is None else limit)
        ledger_path.chmod(0o600)
        result = _resume(provider or FalProvider(), ledger)
        if limit is None:
            for field in ('limit_usd', 'available_usd', 'budget_exceeded'):
                result['ledger_totals'][field] = None
        result['production_hash'] = identity.get('production_hash')
        result['recovery_basis'] = 'stored_job_ids_and_returned_urls; current input, assets, permissions and script review were not consulted'
        _private_json(run / 'production.resume.json', result)
        return result


def validate_production(config, base):
    """Validate offline; return exact-script gate findings and resolved assets."""
    issues, speakers = [], {}
    if not isinstance(config, dict):
        raise ValueError('Production input must be an object.')
    language = config.get('language')
    if not isinstance(language, str) or not language.strip():
        issues.append('language_required')
    try:
        duration = _positive(config.get('target_seconds'), 'target_seconds')
        if duration > 86400:
            issues.append('target_seconds_over_86400')
    except ValueError as exc:
        issues.append(str(exc))
    if config.get('output_mode', 'audio') not in ('audio', 'avatar'):
        issues.append('output_mode_must_be_audio_or_avatar')
    for field in ('tone', 'viewpoint'):
        if not isinstance(config.get(field), str) or not config[field].strip():
            issues.append(field + '_required')
    script = config.get('script')
    if not isinstance(script, dict):
        script = {}
        issues.append('script_required')
    turns = script.get('turns', [])
    if not isinstance(turns, list) or not turns:
        turns = []
        issues.append('nonempty_script_turns_required')
    seen = set()
    for turn in turns:
        if not isinstance(turn, dict):
            issues.append('turn_must_be_object')
            continue
        tid = turn.get('turn_id')
        if not isinstance(tid, str) or not tid or tid in seen:
            issues.append('unique_turn_ids_required')
        seen.add(str(tid))
        if not isinstance(turn.get('text'), str) or not 1 <= len(turn['text'].strip()) <= 10000:
            issues.append('turn_text_requires_1_to_10000_characters')
        if not isinstance(turn.get('speaker_id'), str) or not turn['speaker_id']:
            issues.append('speaker_id_required')
    entries = config.get('speakers', [])
    if not isinstance(entries, list) or not entries:
        entries = []
        issues.append('speakers_required')
    for item in entries:
        if not isinstance(item, dict) or not isinstance(item.get('speaker_id'), str):
            issues.append('invalid_speaker')
            continue
        speaker = dict(item)
        sid = speaker['speaker_id']
        if sid in speakers:
            issues.append('duplicate_speaker_id')
        kind = speaker.get('voice_type', 'stock')
        if kind not in ('stock', 'custom'):
            issues.append('voice_type_must_be_stock_or_custom:' + sid)
        if kind == 'stock':
            speaker['voice_type'] = 'stock'
            speaker['voice_id'] = speaker.get('voice_id') or DEFAULT_STOCK_VOICE
            speaker['voice_identity'] = 'stock_synthesis_voice_not_original_speaker_clone'
            if speaker.get('reference_audio'):
                issues.append('reference_audio_does_not_automatically_create_a_clone:' + sid)
        else:
            if not speaker.get('voice_id'):
                issues.append('custom_voice_missing_existing_voice_id_no_automatic_clone:' + sid)
            permission = speaker.get('permission', {})
            if not isinstance(permission, dict) or permission.get('allowed') is not True or not permission.get('proof_ref'):
                issues.append('custom_voice_permission_required:' + sid)
            else:
                try:
                    speaker['permission_proof'] = _proof(base, permission['proof_ref'], permission.get('proof_hash'))
                except (ValueError, TypeError, OSError) as exc:
                    issues.append('custom_voice_' + str(exc) + ':' + sid)
        if not isinstance(speaker.get('voice_id', ''), str):
            issues.append('voice_id_must_be_text:' + sid)
        if config.get('output_mode', 'audio') == 'avatar':
            try:
                portrait = resolve_path(base, speaker.get('portrait', ''))
                if not speaker.get('portrait') or not portrait.is_file():
                    raise ValueError()
                permission = speaker.get('portrait_permission', speaker.get('permission', {}))
                if not isinstance(permission, dict) or permission.get('allowed') is not True or not permission.get('proof_ref'):
                    issues.append('portrait_permission_required:' + sid)
                else:
                    try:
                        speaker['portrait_permission_proof'] = _proof(base, permission['proof_ref'], permission.get('proof_hash'))
                    except (ValueError, TypeError, OSError) as exc:
                        issues.append('portrait_' + str(exc) + ':' + sid)
                speaker['portrait'] = str(portrait)
                speaker['portrait_hash'] = sha256_file(portrait)
            except (ValueError, TypeError, OSError):
                issues.append('portrait_file_required:' + sid)
        speakers[sid] = speaker
    for turn in turns:
        if isinstance(turn, dict) and turn.get('speaker_id') not in speakers:
            issues.append('unknown_speaker:' + str(turn.get('speaker_id')))
    digest = script_hash(script)
    review = script.get('editorial_review', {})
    if not isinstance(review, dict) or review.get('decision') != 'approved' or review.get('reviewer_type') not in ('human', 'model') or review.get('script_hash') != digest:
        issues.append('independent_exact_script_review_required')
    budget = config.get('budget', {})
    if not isinstance(budget, dict):
        budget = {}
    try:
        _positive(budget.get('total_usd'), 'budget.total_usd')
    except ValueError as exc:
        issues.append(str(exc))
    return issues, speakers, digest


def _resume(provider, ledger):
    report = {'status': 'resume_checked', 'mode': 'GET_only', 'new_submissions': 0, 'checked_jobs': [], 'issues': []}
    for job in ledger.jobs():
        if job['state'] in ('completed', 'cancelled', 'reserved', 'rejected'):
            continue
        urls = job.get('urls') or {}
        if not job.get('request_id') or not urls.get('status_url') or not urls.get('response_url'):
            report['issues'].append('unknown_submission_without_usable_remote_id:' + job['job_id'])
            continue
        try:
            status = provider.status(urls['status_url'])
            state = status.get('status')
            report['checked_jobs'].append({'job_id': job['job_id'], 'provider_status': state})
            if state == 'COMPLETED':
                value = provider.result(urls['response_url'])
                if not isinstance(value, dict) or value.get('error'):
                    ledger.unknown(job['job_id'], 'provider_result_error')
                    report['issues'].append('provider_result_error:' + job['job_id'])
                else:
                    ledger.complete(job['job_id'], value)
            else:
                report['issues'].append('provider_state:' + str(state) + ':' + job['job_id'])
        except Exception as exc:
            report['issues'].append('queue_read_failed:' + type(exc).__name__)
    if report['issues']:
        report['status'] = 'blocked'
    report['next_step'] = 'Run produce --execute with the same input to retrieve verified media and advance; resume never submits new generation.'
    report['ledger_totals'] = ledger.totals()
    return report


def produce(input_path, out, *, dry_run=True, resume=False, provider=None):
    input_path, run = Path(input_path).expanduser().resolve(), Path(out).expanduser().resolve()
    if resume:
        return _resume_existing(run, provider)
    config = read_json(input_path)
    issues, speakers, digest = validate_production(config, input_path.parent)
    authorization_proof = None
    budget = config.get('budget', {})
    if isinstance(budget, dict) and budget.get('authorization_ref'):
        try:
            authorization_proof = _proof(input_path.parent, budget['authorization_ref'], budget.get('authorization_hash'))
        except (ValueError, TypeError, OSError) as exc:
            issues.append('budget_authorization_' + str(exc))
    identity = object_hash({'config': config, 'resolved_speakers': speakers, 'authorization_proof': authorization_proof})
    report = {'schema_version': 1, 'status': 'blocked' if issues else 'dry_run_ready',
              'mode': 'offline_dry_run', 'issues': issues, 'script_hash': digest,
              'production_hash': identity, 'voice_mapping': [{
                  'speaker_id': sid, **({'voice_id': s.get('voice_id')} if s.get('voice_type', 'stock') == 'stock' else {'voice_id_redacted': True}), 'voice_type': s.get('voice_type', 'stock'),
                  'identity': s.get('voice_identity', 'existing_custom_voice_with_permission')} for sid, s in speakers.items()],
              'target_seconds': config.get('target_seconds'), 'measured_seconds': None,
              'new_submissions': 0, 'factual_truth_verified': False,
              'next_step': 'Host agent must resolve findings, verify actual content and permissions, and provide explicit paid-call authorization before --execute.'}
    if dry_run:
        run.mkdir(parents=True, exist_ok=True)
        write_json(run / 'production.dry-run.json', report)
        return report
    run.mkdir(parents=True, exist_ok=True, mode=0o700)
    run.chmod(0o700)
    with open(run / '.production.lock', 'a+') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            report.update(status='blocked', issues=['production_already_running'])
            return report
        identity_path = run / 'production.identity.json'
        if identity_path.exists() and read_json(identity_path).get('production_hash') != identity:
            report.update(status='blocked', issues=['production_input_changed_use_a_new_run_directory'])
            return report
        ledger = Ledger(run / 'ledger.sqlite', config.get('budget', {}).get('total_usd', 0))
        provider = provider or FalProvider()
        (run / 'ledger.sqlite').chmod(0o600)
        budget = config.get('budget', {})
        if config.get('allow_paid_calls', budget.get('allow_paid_calls')) is not True or authorization_proof is None:
            issues.append('explicit_allow_paid_calls_and_budget_authorization_ref_required')
        if not getattr(provider, 'key', None):
            issues.append('missing_credential:FAL_KEY')
        if issues:
            report.update(status='blocked', issues=issues)
            write_json(run / 'production.json', report)
            return report
        write_json(identity_path, {'production_hash': identity, 'script_hash': digest, 'budget_limit_usd': budget['total_usd'], 'authorization_proof': authorization_proof, 'speaker_proofs': {sid: {key: value for key, value in speaker.items() if key in ('permission_proof', 'portrait_permission_proof', 'portrait_hash')} for sid, speaker in speakers.items()}, 'created_at': now()})
        _private_json(run / 'production.input.json', config)
        before = {j['job_id']: j['state'] for j in ledger.jobs()}
        report.update(mode='execute', status='blocked')
        path = run / 'production.json'
        try:
            prices = {}
            endpoints = [(ROUTE[1], 'tts_per_1000_chars_usd')]
            if config.get('output_mode', 'audio') == 'avatar':
                endpoints.append((ROUTE[2], 'video_per_second_usd'))
            receipts = []
            for endpoint, setting in endpoints:
                raw = provider.pricing(endpoint)
                quote = _normalise_price(raw, endpoint, setting)
                prices[setting] = quote['normalized_unit_price']
                receipts.append({'endpoint': endpoint, 'retrieved_at': now(), 'response': raw, 'normalized': quote})
            write_json(run / 'pricing.json', {'mode': 'authenticated_GET_only', 'quotes': receipts})
            script = config['script']
            turns = script['turns']
            audio_dir = run / 'media' / digest
            audio_dir.mkdir(parents=True, exist_ok=True)
            parts = []
            for index, turn in enumerate(turns):
                speaker = speakers[turn['speaker_id']]
                boost = {'en': 'English', 'zh': 'Chinese'}.get(config['language'], config['language'])
                payload = {'prompt': turn['text'], 'voice_setting': {'voice_id': speaker['voice_id']},
                           'language_boost': boost, 'output_format': 'url'}
                spec = {'production_hash': identity, 'script_hash': digest, 'turn': turn,
                        'endpoint': ROUTE[1], 'payload': payload}
                result = run_job(provider, ledger, 'tts', object_hash(spec),
                                 len(turn['text']) / 1000 * prices['tts_per_1000_chars_usd'], ROUTE[1],
                                 lambda payload=payload: payload, metadata=spec,
                                 poll_seconds=min(float(config.get('poll_seconds', 0)), 30))
                normalized = {'audio': result.get('audio') or result.get('outputaudio') or (result.get('output') or {}).get('audio')}
                part = _download(provider, normalized, 'audio', audio_dir / ('tts_%03d.mp3' % index))
                if not part['media_info'].get('has_audio'):
                    raise RenderBlocked('downloaded_tts_has_no_audio')
                part.update(turn_id=turn['turn_id'], speaker_id=turn['speaker_id'])
                parts.append(part)
            freeze_path = audio_dir / 'audio.json'
            if freeze_path.exists():
                frozen = read_json(freeze_path)
                if not _cached_artifact(frozen['path'], frozen['checksum']) or any(not _cached_artifact(c['path'], c['checksum']) for c in frozen['chunks']):
                    raise RenderBlocked('frozen_audio_changed')
            else:
                frozen = _freeze_audio(parts, audio_dir, digest)
                write_json(freeze_path, frozen)
            report['audio'] = frozen
            report['measured_seconds'] = frozen['duration_seconds']
            if config.get('output_mode', 'audio') == 'avatar':
                if any(c['duration_seconds'] > 60 for c in frozen['chunks']):
                    raise RenderBlocked('avatar_turn_over_60_seconds_resegment_the_reviewed_script_in_a_new_run')
                videos = []
                for index, chunk in enumerate(frozen['chunks']):
                    speaker = speakers[chunk['speaker_id']]
                    spec = {'production_hash': identity, 'endpoint': ROUTE[2], 'script_hash': digest,
                            'turn_id': chunk['turn_id'], 'image_hash': speaker['portrait_hash'],
                            'audio_hash': chunk['checksum'], 'frozen_audio_hash': frozen['audio_hash'], 'prompt': AVATAR_PROMPT,
                            'billing_estimated_bound': {'input_audio_seconds': chunk['duration_seconds'],
                                'reserved_output_seconds': math.ceil(chunk['duration_seconds']) + 2,
                                'basis': 'rounded_input_plus_2_seconds_output_padding_allowance_not_actual_bill'},
                            'portrait_permission_proof': speaker['portrait_permission_proof']}
                    value = run_job(provider, ledger, 'avatar_video', object_hash(spec),
                                    spec['billing_estimated_bound']['reserved_output_seconds'] * prices['video_per_second_usd'], ROUTE[2],
                                    lambda speaker=speaker, chunk=chunk: {'image_url': provider.upload(speaker['portrait']),
                                        'audio_url': provider.upload(chunk['path']), 'prompt': AVATAR_PROMPT}, metadata=spec,
                                    poll_seconds=min(float(config.get('poll_seconds', 0)), 30))
                    videos.append(_download(provider, value, 'video', audio_dir / ('avatar_%03d.mp4' % index)))
                report['segments'] = videos
                report['video'] = _assemble(videos, frozen, audio_dir)
            report.update(status='succeeded', issues=[], next_step='Review the actual output privately. No automatic publication was authorized.')
        except Exception as exc:
            report['issues'] = [type(exc).__name__ + ': ' + str(exc)]
            report['next_step'] = 'Resolve this recorded dependency. For queued or unknown requests use --resume; never resubmit blindly.'
        report['ledger_totals'] = ledger.totals()
        report['new_submissions'] = len([j for j in ledger.jobs() if before.get(j['job_id'], 'reserved') == 'reserved' and j['state'] not in ('reserved', 'cancelled')])
        write_json(path, report)
        return report
