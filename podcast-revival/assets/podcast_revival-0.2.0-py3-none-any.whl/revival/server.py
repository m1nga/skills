import json,mimetypes,re,secrets,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,unquote
from .app import save_credential
from .util import resolve_path,read_json,sha256_file

def serve(project,port=4317):
    csrf=secrets.token_urlsafe(32);lock=threading.Lock();web=Path(__file__).parent/'web'
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def valid_host(self):return self.headers.get('Host') in (f'127.0.0.1:{port}',f'localhost:{port}')
        def send_headers(self,status,kind,length=None):
            self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
            if length is not None:self.send_header('Content-Length',str(length))
        def send_json(self,obj,status=200):
            b=json.dumps(obj,ensure_ascii=False).encode();self.send_headers(status,'application/json',len(b));self.end_headers();self.wfile.write(b)
        def do_GET(self):
            if not self.valid_host():return self.send_json({'error':'Invalid local host'},403)
            path=urlparse(self.path).path
            if path=='/api/state':return self.send_json(dict(project.state(),csrf_token=csrf))
            if path.startswith('/artifact/'):
                parts=path.split('/')
                if len(parts)!=4 or parts[3] not in ('video','audio'):return self.send_json({'error':'Not found'},404)
                manifest=project.run/'media.json'
                if not manifest.is_file():return self.send_json({'error':'Generated media is not available'},404)
                deliverable=next((d for d in read_json(manifest).get('deliverables',[]) if d.get('deliverable_id')==unquote(parts[2])),{})
                asset=deliverable.get(parts[3]) or {}
                target=Path(asset.get('path','')).resolve()
                if not target.is_relative_to(project.run.resolve()) or not target.is_file() or not asset.get('checksum') or sha256_file(target)!=asset['checksum']:
                    return self.send_json({'error':'Verified generated artifact is not available'},404)
                return self.file(target)
            if path.startswith('/media/'):
                parts=path.split('/')
                if len(parts)!=4:return self.send_json({'error':'Not found'},404)
                kind,sid=parts[2:];s=next((s for s in project.config['sources'] if s['source_id']==sid),None)
                field={'source':'local_path','thumbnail':'thumbnail_path','context':'context_audio_path'}.get(kind)
                if not s or not field or not s.get(field):return self.send_json({'error':'Media is not available'},404)
                return self.file(resolve_path(project.base,s[field]))
            if path=='/api/export':
                report=project.state();b=json.dumps(report,ensure_ascii=False,indent=2).encode();self.send_headers(200,'application/json',len(b));self.send_header('Content-Disposition','attachment; filename="revival-project-report.json"');self.end_headers();self.wfile.write(b);return
            target={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/launch-card.svg':'launch-card.svg'}.get(path)
            if target:return self.file(web/target)
            self.send_json({'error':'Not found'},404)
        def file(self,path):
            if not path.is_file():return self.send_json({'error':'File not available'},404)
            size=path.stat().st_size;start,end=0,max(0,size-1);partial=False
            ran=self.headers.get('Range')
            if ran:
                match=re.fullmatch(r'bytes=(\d*)-(\d*)',ran)
                if not match:return self.send_json({'error':'Invalid range'},416)
                a,b=match.groups()
                if a:start=int(a);end=min(int(b),end) if b else end
                elif b:start=max(0,size-int(b))
                if start>=size or start>end:return self.send_json({'error':'Range outside media'},416)
                partial=True
            self.send_headers(206 if partial else 200,mimetypes.guess_type(str(path))[0] or 'application/octet-stream',end-start+1)
            self.send_header('Accept-Ranges','bytes')
            if partial:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            try:
                with path.open('rb') as stream:
                    stream.seek(start);remaining=end-start+1
                    while remaining:
                        data=stream.read(min(1024*256,remaining))
                        if not data:break
                        self.wfile.write(data);remaining-=len(data)
            except (BrokenPipeError,ConnectionResetError):pass
        def do_POST(self):
            if not self.valid_host() or self.headers.get('X-Revival-Token')!=csrf:return self.send_json({'error':'Invalid local request token'},403)
            origin=self.headers.get('Origin')
            if origin and origin not in (f'http://127.0.0.1:{port}',f'http://localhost:{port}'):return self.send_json({'error':'Invalid origin'},403)
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=20000:return self.send_json({'error':'Invalid body size'},400)
            if not lock.acquire(blocking=False):return self.send_json({'error':'Another action is still running'},409)
            try:
                data=json.loads(self.rfile.read(length));path=urlparse(self.path).path
                if path=='/api/action':result=project.action(data.get('action'))
                elif path=='/api/selection':project.update_selection(data['source_id'],data['start_ms'],data['end_ms']);result={'status':'saved'}
                elif path=='/api/credential':save_credential(data.get('name'),data.get('value'));result={'status':'saved_in_macos_keychain'}
                else:return self.send_json({'error':'Unknown action'},404)
                self.send_json(result)
            except Exception as exc:self.send_json({'error':str(exc)},400)
            finally:lock.release()
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    print(f'Revival is ready at http://127.0.0.1:{port}',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:server.server_close()
